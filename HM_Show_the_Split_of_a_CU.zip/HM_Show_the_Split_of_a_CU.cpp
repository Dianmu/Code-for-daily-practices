#include <iostream>
#include <ctime>
#include <cstdlib>
#include <cstdio>
#include <unordered_map>
#include <vector>
#include <algorithm>
#include <set>
#include <stack>

using namespace std;


/*This is the application of convert VP9 decoded information to HEVC
 *encoding information. This main() read from "test_in.txt", where VP9
 *block partition information is preserved using Z order, the main()
 *write to "test_out.txt" the corresponding Splitting Structure.
 */

/*1、fill_raster() is used to convert Splitting Structure for each CU
 *2、print_raster() is used to print the result of fill_raster(), then by
 *manipulating the file pointer to show the Structure as is seen in a frame.
 *3、CUcount is the consecutive CU number;
 *4、MAX_CU_COUNT is the max CU number allowed in a row. 
 */
int ZtoR[256]={0,1,16,17,2,3,18,19,32,33,48,49,34,35,50,51,
               4,5,20,21,6,7,22,23,36,37,52,53,38,39,54,55,
               64,65,80,81,66,67,82,83,96,97,112,113,98,99,114,115,
                68,69,84,85,70,71,86,87,100,101,116,117,102,103,118,119,
                8,9,24,25,10,11,26,27,40,41,56,57,42,43,58,59,
                12,13,28,29,14,15,30,31,44,45,60,61,46,47,62,63,
                72,73,88,89,74,75,90,91,104,105,120,121,106,107,122,123,
                76,77,92,93,78,79,94,95,108,109,124,125,110,111,126,127,
                128,129,144,145,130,131,146,147,160,161,176,177,162,163,178,179,
                132,133,148,149,134,135,150,151,164,165,180,181,166,167,182,183,
                192,193,208,209,194,195,210,211,224,225,240,241,226,227,242,243,
                196,197,212,213,198,199,214,215,228,229,244,245,230,231,246,247,
                136,137,152,153,138,139,154,155,168,169,184,185,170,171,186,187,
                140,141,156,157,142,143,158,159,172,173,188,189,174,175,190,191,
                200,201,216,217,202,203,218,219,232,233,248,249,234,235,250,251,
                204,205,220,221,206,207,222,223,236,237,252,253,238,239,254,255};
//=====================================================================
void fill_raster(const int&edge,char*raster_print,int &offset){
    int len=edge/4;
    int depth=0;
    switch(len){
        case 16:depth=0;break;
        case 8:depth=1;break;
        case 4:depth=2;break;
        case 2:depth=3;break;
        case 1:depth=4;break;
    }
    for(int i=0;i<len;++i){
        for(int j=0;j<len;++j){
            switch(i*len+j){
                case 0:case 1:case 4:case 5:case 16:case 17:case 20:case 21:
                case 64:case 65:case 68:case 69:case 80:case 81:case 84:case 85:
                case 2:case 8:case 10:case 32:case 34:case 40:case 42:case 128:
                case 130:case 136:case 138:case 160:case 162:case 168:case 170:
                    raster_print[ZtoR[offset+i*len+j]]='+';break;
                default:raster_print[ZtoR[offset+i*len+j]]=' ';break;
            }
        }
    }
    offset+=len*len;
}
void print_raster(FILE*fp,const char*raster_print,const int CUcount,const int MAX_CU_COUNT){
    int offset=(CUcount%MAX_CU_COUNT)*32+16*(MAX_CU_COUNT*32+1)*(CUcount/MAX_CU_COUNT);
    fseek(fp,offset,SEEK_SET);
    for(int i=0;i<16;++i){
        if(CUcount%MAX_CU_COUNT==0){
            for(int j=0;j<16;++j){
                //the "space" after "%c" should also be calculated
                //during the file_pointer manipulation process
                fprintf(fp,"%c ",raster_print[i*16+j]);
            }
            fprintf(fp,"\n");
        }else{
            int first_half=offset+i*32+i+i*32*(CUcount%MAX_CU_COUNT);
            fseek(fp,0,SEEK_END);
            int length=ftell(fp);
            int diff=length-first_half;
            char*tmp_buffer=new char[diff];
            fseek(fp,first_half,SEEK_SET);
            fread(tmp_buffer,1,diff,fp);
            fseek(fp,first_half,SEEK_SET);
            for(int j=0;j<16;++j){
                //the "space" after "%c" should also be calculated
                //during the file_pointer manipulation process
                fprintf(fp,"%c ",raster_print[i*16+j]);
            }
            fwrite(tmp_buffer,1,diff,fp);
            delete[]tmp_buffer;
        }
    }
}
//=====================================================================

int main(){
    time_t start=clock();
    srand(time(NULL));
//=====================================================================
    FILE*fp_in,*fp_out;
    fp_in=fopen("test_in.txt","rb+");
    fp_out=fopen("test_out.txt","wb+");
    int edge=0,area=0,offset=0,CUcount=0;
    const int MAX_CU_COUNT=3;
    char raster_print[256]={0};
    while(fscanf(fp_in,"%i",&edge)!=EOF){
        area+=edge*edge;
        fill_raster(edge,raster_print,offset);
        if(area==4096){
            print_raster(fp_out,raster_print,CUcount,MAX_CU_COUNT);
            ++CUcount;
            area=0;
            offset=0;
        }
    }
    fclose(fp_in);
    fclose(fp_out);

//=====================================================================
    time_t end=clock();
    cout<<'\n'<<"【Running time : ";
    cout<<(double)(end-start)*1000/CLOCKS_PER_SEC<<" ms】\n\n";
    return 0;
}