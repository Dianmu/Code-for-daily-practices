#ifndef CONCRETE_PRODUCT_H
#define CONCRETE_PRODUCT_H
#include "Product.h"

class BenzCar : public ICar{
public:
	string Name(){
		return "Benz Car";
	}
};

class AudiCar : public ICar{
public:
	string Name(){
		return "Audi Car";
	}
};

class BmwCar : public ICar{
public:
	string Name(){
		return "Bmw Car";
	}
};

#endif