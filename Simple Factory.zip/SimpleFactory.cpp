#include "Factory.h"
#include "Product.h"
#include "Concrete_Product.h"
#include <iostream>


using namespace std;

int main(){
	Factory *pFactory = new Factory();
	ICar *pCar = pFactory->CreateCar(Factory::BENZ_CAR);
	cout << pCar->Name() << endl;

	pCar = pFactory->CreateCar(Factory::AUDI_CAR);
	cout << pCar->Name() << endl;


	pCar = pFactory->CreateCar(Factory::BMW_CAR);
	cout << pCar->Name() << endl;


	return 0;
}