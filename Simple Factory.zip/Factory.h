#ifndef FACTORY_H
#define FACTORY_H
#include "Concrete_Product.h"

class Factory{
public:
	enum CAR_TYPE{
		BENZ_CAR,
		AUDI_CAR,
		BMW_CAR
	};
	ICar* CreateCar(CAR_TYPE type){
		ICar *pCar = nullptr;
		switch(type){
			case CAR_TYPE::BENZ_CAR:
				pCar = new BenzCar();
				break;
			case CAR_TYPE::AUDI_CAR:
				pCar = new AudiCar();
				break;
			case CAR_TYPE::BMW_CAR:
				pCar = new BmwCar();
				break;
		}
		return pCar;
	}
};

#endif